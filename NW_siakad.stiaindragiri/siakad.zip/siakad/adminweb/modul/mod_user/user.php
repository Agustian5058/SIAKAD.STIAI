<?php
$aksi="modul/mod_user/aksi_user.php";
switch($_GET[act]) {
	// Tampil User
	default:
	echo "<h2>User</h2>
	<input type=button value='Tambah User' class='btn btn-primary' onclick=\"window.location.href='?module=user&act=tambahuser';\">
	
	<table  id='sample-table-2' class='table table-striped table-bordered table-hover'><thead>
		<tr><th>No.</th><th>Username</th><th>Nama Lengkap</th><th>Email</th><th>No. Telp/HP</th>
			<th>Blokir</th><th>Aksi</th></tr></thead>";
	$tampil=mysql_query("SELECT * FROM users ORDER BY id_user");
	$no=1;
	while($r=mysql_fetch_array($tampil)) {
		echo "<tr><td>$no</td>
				<td>$r[id_user]</td>
				<td>$r[nama_lengkap]</td>
				<td><a href=mailto:$r[email]>$r[email]</a></td>
				<td>$r[no_telp]</td>
				<td align=center>$r[blokir]</td>
				<td><a href=?module=user&act=edituser&id=$r[id_user]>Edit</a> | 
					<a href=$aksi?module=user&act=hapus&id=$r[id_user]>Hapus</a></td>
			</tr>";
		$no++;
	}
	
echo "</table>";
break;

case "tambahuser":
echo "<h2>Tambah User</h2>
	<form method=POST action='$aksi?module=user&act=input'>
	<table class='table table-striped table-bordered table-hover'>
		<tr>
			<td>Username</td>
			<td> : <input type=text name='username'></td>
		</tr>
		<tr>
			<td>Password</td>
			<td> : <input type=text name='password'></td>
		</tr>
		<tr>
			<td>Nama Lengkap</td>
			<td> : <input type=text name='nama_lengkap' size=30></td>
		</tr>
		<tr>
			<td>E-mail</td>
			<td> : <input type=text name='email' size=30></td>
		</tr>
		<tr>
			<td>No. Telp</td>
			<td> : <input type=text name='no_telp' size=20></td>
		</tr>
		<tr>
			<td colspan=2><input type=submit class='btn btn-primary' value=Simpan> <input class='btn btn-primary' type=button value=Batal onclick=self.history.back()></td>
		</tr>
	</table>
</form>";
break;

case "edituser":
$edit=mysql_query("SELECT * FROM users WHERE id_user='$_GET[id]'");
$r=mysql_fetch_array($edit);

echo "<h2>Edit User</h2>
<form method=POST action=$aksi?module=user&act=update>
<input type=hidden name=id value='$r[id_user]'>

<table class='table table-striped table-bordered table-hover'>
<tr>
	<td>Username</td>
	<td> : <input type=text name='username' value='$r[id_user]'></td>
</tr>
<tr>
	<td>Password</td>
	<td> : <input type=text name='password'> *)</td>
</tr>
<tr>
	<td>Nama Lengkap</td>
	<td> : <input type=text name='nama_lengkap' size=30 value='$r[nama_lengkap]'></td>
</tr>
<tr>
	<td>E-mail</td>
	<td> : <input type=text name='email' size=30 value='$r[email]'></td>
</tr>
<tr>
	<td>No. Telp</td>
	<td> : <input type=text name='no_telp' size=30 value='$r[no_telp]'></td>
</tr>";

if ($r[blokir]=='N') {
	echo "<tr><td>Blokir</td>
			<td> : <input type=radio name='blokir' value='Y'><span class='lbl'> Y
			<input type=radio name='blokir' value='N' checked><span class='lbl'> N </td></tr>";
}
else {
	echo "<tr><td>Blokir</td>
			<td> : <input type=radio name='blokir' value='Y' checked><span class='lbl'> Y
			<input type=radio name='blokir' value='N'><span class='lbl'> N </td></tr>";
}
echo "<tr><td colspan=2>*) Apabila password tidak diubah, dikosongkan saja.</td></tr>
	<tr><td colspan=2><input type=submit class='btn btn-primary' value=Update> <input type=button class='btn btn-primary' value=Batal onclick=self.history.back()></td></tr>
	</table></form>";
break;
}
?>